Para que el filtro funciones es necesario seguir los siguientes pasos :

1) Modificar la ruta en la que se encuentra la carpeta con los mails en el fichero filtro_spam.py

2) Si se usa windows es necesario cambiar la bara de '/ham/*.txt' y '/spam/*.txt' en el fichero load_mails_example.py

3) para ejecutarlo hay que escribir "python filtro_spam.py" en la linea de comandos
